chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'startCrawl') {
    var urls = [];
    var links = document.getElementsByTagName('a');
    for (var i = 0; i < links.length; i++) {
      urls.push(links[i].href);
    }
    chrome.downloads.download({
      url: 'data:text/csv;charset=utf-8,' + encodeURI(urls.join('\n')),
      filename: 'urls.csv'
    });
  }
});
